create definer = ssafy@`%` trigger UpdateReportedCountAfterInsert
    after insert
    on reports
    for each row
BEGIN
    -- reported_user_id를 가진 사용자의 reported_cnt를 업데이트
    UPDATE users
    SET reported_cnt = reported_cnt + 1
    WHERE user_id = NEW.reported_user_id;
END;

