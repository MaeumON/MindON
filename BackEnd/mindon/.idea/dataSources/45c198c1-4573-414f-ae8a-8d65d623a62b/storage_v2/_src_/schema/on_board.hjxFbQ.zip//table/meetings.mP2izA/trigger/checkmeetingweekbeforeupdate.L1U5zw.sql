create definer = ssafy@`%` trigger CheckMeetingWeekBeforeUpdate
    before update
    on meetings
    for each row
BEGIN
    IF NEW.meeting_week < 1 OR NEW.meeting_week > `groups`.period THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'meeting_week must be between 1 and the value of period';
    END IF;
END;

