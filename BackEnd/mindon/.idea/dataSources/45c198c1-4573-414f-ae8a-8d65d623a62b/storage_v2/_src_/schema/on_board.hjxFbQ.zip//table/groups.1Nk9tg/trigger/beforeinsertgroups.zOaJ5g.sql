create definer = ssafy@`%` trigger BeforeInsertGroups
    before insert
    on `groups`
    for each row
BEGIN
    DECLARE new_code VARCHAR(10);
    DECLARE code_exists INT;

    SET new_code = (SELECT CONCAT(
                                   SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1),
                                   SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1),
                                   SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1),
                                   SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1),
                                   SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1),
                                   SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1),
                                   SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1),
                                   SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1)
                           ));

    -- 코드 중복 검사
    SELECT COUNT(*) INTO code_exists FROM `groups` WHERE invite_code = new_code;
    WHILE code_exists > 0 DO
            SET new_code = (SELECT CONCAT(
                                           SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1),
                                           SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1),
                                           SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1),
                                           SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1),
                                           SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1),
                                           SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1),
                                           SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1),
                                           SUBSTRING('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', FLOOR(RAND()*36)+1, 1)
                                   ));
            SELECT COUNT(*) INTO code_exists FROM `groups` WHERE invite_code = new_code;
        END WHILE;

    SET NEW.invite_code = new_code;
END;

