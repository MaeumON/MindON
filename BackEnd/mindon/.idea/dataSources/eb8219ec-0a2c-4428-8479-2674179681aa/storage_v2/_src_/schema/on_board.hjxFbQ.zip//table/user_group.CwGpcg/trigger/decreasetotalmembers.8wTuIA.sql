create definer = ssafy@`%` trigger DecreaseTotalMembers
    after delete
    on user_group
    for each row
BEGIN
    UPDATE `groups`
    SET total_member = total_member - 1
    WHERE group_id = OLD.group_id;
END;

