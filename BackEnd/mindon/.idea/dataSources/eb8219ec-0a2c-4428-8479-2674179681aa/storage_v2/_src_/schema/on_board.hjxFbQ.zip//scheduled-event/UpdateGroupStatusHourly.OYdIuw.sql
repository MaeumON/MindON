create definer = ssafy@`%` event UpdateGroupStatusHourly on schedule
    every '1' SECOND
        starts '2025-01-24 00:00:00'
    enable
    do
    BEGIN
        UPDATE `groups`
        SET group_status = CASE
            WHEN CURDATE() < start_date THEN 0
            WHEN CURDATE() >= start_date AND CURDATE() <= DATE_ADD(end_date, INTERVAL 1 HOUR) THEN 1
            ELSE 2
        END;
    END;

