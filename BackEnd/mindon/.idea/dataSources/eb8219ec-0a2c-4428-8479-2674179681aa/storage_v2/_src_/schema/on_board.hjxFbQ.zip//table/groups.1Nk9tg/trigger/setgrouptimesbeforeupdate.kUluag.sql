create definer = ssafy@`%` trigger SetGroupTimesBeforeUpdate
    before update
    on `groups`
    for each row
BEGIN
    -- start_date와 end_date의 시간을 meeting_time 값으로 설정
    SET NEW.start_date = TIMESTAMP(NEW.start_date, CONCAT(LPAD(NEW.meeting_time, 2, '0'), ':00:00'));
    SET NEW.end_date = TIMESTAMP(NEW.end_date, CONCAT(LPAD(NEW.meeting_time, 2, '0'), ':00:00'));
END;

