create definer = ssafy@`%` trigger CalculateEndDateBeforeInsert
    before insert
    on `groups`
    for each row
BEGIN
    -- start_date로부터 period 주 만큼 후의 날짜를 end_date로 계산
    SET NEW.end_date = DATE_ADD(NEW.start_date, INTERVAL (NEW.period - 1) WEEK);
END;

