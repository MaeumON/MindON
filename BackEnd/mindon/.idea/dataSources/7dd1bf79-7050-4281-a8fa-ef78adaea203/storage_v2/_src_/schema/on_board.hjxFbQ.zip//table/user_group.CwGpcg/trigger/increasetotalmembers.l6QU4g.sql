create definer = ssafy@`%` trigger IncreaseTotalMembers
    after insert
    on user_group
    for each row
BEGIN
    UPDATE `groups`
    SET total_member = total_member + 1
    WHERE group_id = NEW.group_id;
END;

