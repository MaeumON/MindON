create definer = ssafy@`%` trigger BeforeUpdateReportCount
    before update
    on users
    for each row
BEGIN
    IF NEW.reported_cnt >= 3 AND OLD.reported_cnt < 3 THEN
        SET NEW.user_status = 2;
    END IF;
END;

